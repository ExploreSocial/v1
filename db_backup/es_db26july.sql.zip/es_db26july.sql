-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 26, 2015 at 11:36 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `exploresocial`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_fields`
--

CREATE TABLE IF NOT EXISTS `form_fields` (
`field_id` bigint(20) NOT NULL,
  `suite_id` bigint(20) NOT NULL,
  `field_title` varchar(200) NOT NULL,
  `field_tagline` varchar(200) DEFAULT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `form_result`
--

CREATE TABLE IF NOT EXISTS `form_result` (
`res_id` bigint(20) NOT NULL,
  `field_id` bigint(20) NOT NULL,
  `suite_id` bigint(20) NOT NULL,
  `answer` text NOT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prize`
--

CREATE TABLE IF NOT EXISTS `prize` (
`prize_id` bigint(20) NOT NULL,
  `suite_id` bigint(20) NOT NULL,
  `prize_title` varchar(200) NOT NULL,
  `prize_img` varchar(200) DEFAULT NULL,
  `prize_desc` varchar(200) NOT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `socialsuite`
--

CREATE TABLE IF NOT EXISTS `socialsuite` (
`suite_id` bigint(20) NOT NULL,
  `type` tinyint(2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `description` text NOT NULL,
  `venue` varchar(200) DEFAULT NULL,
  `cover_image` varchar(200) DEFAULT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `tagline` varchar(200) DEFAULT NULL,
  `org_name` varchar(100) NOT NULL,
  `org_email` varchar(100) NOT NULL,
  `org_phone` varchar(20) NOT NULL,
  `org_details` text,
  `url` varchar(250) NOT NULL,
  `facebook_url` varchar(100) DEFAULT NULL,
  `twitter_handle` varchar(100) DEFAULT NULL,
  `insta` varchar(100) DEFAULT NULL,
  `website_url` varchar(200) DEFAULT NULL,
  `tnc` text NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
`ticket_id` bigint(5) NOT NULL,
  `ticket_name` varchar(100) NOT NULL,
  `ticket_description` text,
  `price` varchar(50) NOT NULL,
  `qty` int(5) NOT NULL,
  `max_qty` int(5) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(220) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `pass`, `created_on`, `updated_on`) VALUES
(1, '''karanrai''', 'karan.r.86@gmail.com', '$2y$10$T62eu76d7t1C5Cnwjh7c3.KhTiCHLicjQ', '2015-06-08 19:33:45', '2015-06-08 19:33:45'),
(2, 'kiranrai', 'kiran@gmail.com', '$2y$10$2FNbj0fJ1gumIIPtC18lx.CKXlBIKLx96', '2015-06-08 19:52:14', '2015-06-08 19:52:14'),
(3, 'testsingh', 'test@testsingh.com', '$2y$10$XBaDp5/rlmv8vIc/X2g6GeKM5V4wIxhWr', '2015-06-21 07:44:53', '2015-06-21 07:44:53'),
(4, 'yo', 'yo@a.in', '$2y$10$Ab6NkyWYD/v17YoN7PIt1ekGxd.krQHcs', '2015-06-21 08:24:36', '2015-06-21 08:24:36'),
(5, 'jhum', 'jhum@testsingh.com', '$2y$10$xzUGTzv6au/L1lVI2G/.2OheRAPHiWMlz', '2015-06-21 08:32:39', '2015-06-21 08:32:39'),
(6, 'hello', 'a@a.in', '$2y$10$KrbVv.OJnNrvSfATszkkwe2rEA3sFxMZA', '2015-06-21 09:05:26', '2015-06-21 09:05:26'),
(7, 'bb', 'bb@bb.in', '$2y$10$r4UCJlHGXVUZh8vHbICGaONP0JE8fBECj', '2015-06-21 09:09:40', '2015-06-21 09:09:40'),
(8, 'EE', 'ee@ee.in', '$2y$10$rEAmtT7nChvB2q8mHlFbseH5z2ehx9G/.', '2015-06-21 09:12:29', '2015-06-21 09:12:29'),
(9, 'elephant', 'elephant@213.com', '$2y$10$QYeUw6v8r8NCqQjYaPoPN.M6/eP9MIVJB', '2015-06-21 09:17:41', '2015-06-21 09:17:41'),
(10, 'co', 'co@co.in', '$2y$10$pZRJdWkvYbyI6.8FfNeRVuyC3set6Jf2/', '2015-06-21 09:21:34', '2015-06-21 09:21:34'),
(11, 'helloworld', 'hello@helloworld.com', '$2y$10$hDHZPjcSNK9WyuYT2oO32euouVJpWznKDp2f6zOpOne5sAUSlCvkS', '2015-06-21 09:24:32', '2015-06-21 09:24:32'),
(12, 'hello', 'hello@hello.com', '$2y$10$AqPQJ1kB6txgIFnKxysylOVLyACjj7USCIwrnGbDXnPnunBz/T9ES', '2015-06-24 17:06:52', '2015-06-24 17:06:52'),
(13, 'nisha.rai', 'nisha.delhi@gmail.com', '$2y$10$o86i2KdWgSqaYmzhSqt/vOIhH4POYkJp7VtR7McpBZ460F4j7n4aG', '2015-07-04 13:51:24', '2015-07-04 13:51:24'),
(14, 'test', 'test@test.in', '$2y$10$fUGUujRaHT11aibffOIKEeA8VChFQPhB6i.BLz7uwAjWeKMxuccrm', '2015-07-04 14:21:48', '2015-07-04 14:21:48'),
(15, 'test', 'test@test.com', '$2y$10$mROnnbKhjSNozt19OjGht.63xLm9cFS0VLJEmwPyUQJn4UmvuezUy', '2015-07-04 15:49:18', '2015-07-04 15:49:18'),
(16, 'testing', 'test@test.india', '$2y$10$kT1AQCCk3jBff/J8mx1mUO3MNdwSpy0a84j9jwQe2AdsfyVaP84GW', '2015-07-04 17:25:20', '2015-07-04 17:25:20'),
(17, 'test2', 'test2@test.in', '$2y$10$e.5ZvNHTgYx.5IuyaBUcc.OAAsfb0a9hYRi7C57EQsWcWQ6FpvQzG', '2015-07-11 13:01:35', '2015-07-11 13:01:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form_fields`
--
ALTER TABLE `form_fields`
 ADD PRIMARY KEY (`field_id`);

--
-- Indexes for table `form_result`
--
ALTER TABLE `form_result`
 ADD PRIMARY KEY (`res_id`);

--
-- Indexes for table `prize`
--
ALTER TABLE `prize`
 ADD PRIMARY KEY (`prize_id`);

--
-- Indexes for table `socialsuite`
--
ALTER TABLE `socialsuite`
 ADD PRIMARY KEY (`suite_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
 ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form_fields`
--
ALTER TABLE `form_fields`
MODIFY `field_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `form_result`
--
ALTER TABLE `form_result`
MODIFY `res_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prize`
--
ALTER TABLE `prize`
MODIFY `prize_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `socialsuite`
--
ALTER TABLE `socialsuite`
MODIFY `suite_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
MODIFY `ticket_id` bigint(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
